import requests
from requests.packages import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import json

# Set NCM server URL and API key
ncm_url = "https://is-config-manager.mn-man.biz"
api_key = "d407b59cc111b42a7f95089626612f47"

# Get list of device IDs
devices_url = ncm_url + "/api/json/v2/ncmdevice/listAllDevices?apiKey="+api_key
# print(devices_url)
response = requests.get(devices_url, verify=False)
devices_data = json.loads(response.text)["rows"]
device_ids = [device["id"] for device in devices_data]
#device_ids = "10.82.248.89"
# device_ids = ["20000002705", "20000001148", "20000002280", "20000002320", "20000002348"]
#print(device_ids)

# Get backup information for each device
backup_info = {}
for device_id in device_ids:
    backup_url = ncm_url + "/api/json/ncmdevice/devSummary?apiKey="+api_key+"&deviceId="+str(device_id)
#    print(backup_url)
    response = requests.get(backup_url, verify=False)
    backup_data = json.loads(response.text)["devDetails"]
    
    backup_info[device_id] = backup_data
#    print(backup_data)

with open("backup_info.txt", "w") as file:
    for device_id, backup_data in backup_info.items():
#        file.write("Device ID:" + device_id + "\n")
        file.write("***************"+"\n")
        file.write("Device Name:" + backup_data["HostName"] + "\n")
        file.write("IP Address:" + backup_data["IPAddress"] + "\n")
        file.write("Last Backup Time:" + backup_data["LastSuccessfulOperationAt"] + "\n")
        file.write("Backup Status:" + backup_data["LastOperationStatus"] + "\n")
