#!/usr/bin/env python3

"""
This plugin verifies that the F5-full backup files are being stored/written on the FIOBC-SEC probe on a regular basis
USAGE:
python3 check_f5_full_backup.py -host IBDDWFXHPA64689
OK - The full backup file for I_BDDWFXHPA64689 has been backed up successfully.
python3 check_f5_full_backup.py -host IBDDWFXHPA64681
CRITICAL - Full backup file for IBDDWFXHPA64681 not found or not updated in the last 24 hours.
"""

import argparse
import os
import sys  # Importing the sys module to use sys.exit()
import datetime


def check_backup_file(host):
    """Check if the F5-full backup file exists for the given host."""
    # Define the backup directory
    backup_dir = "/NCM/backup/"

    # Get the current date in the format 'YYYYMMDD'
    current_date = datetime.datetime.now().strftime("%Y%m%d")

    # Create the expected filename based on the provided host and current date
    filename = f"{host}_{current_date}.ucs"

    full_path = os.path.join(backup_dir, filename)

    if os.path.exists(full_path):
        # If the expected backup file exists, print an "OK" message.
        print(f"OK - The full backup file for {host} has been backed up successfully. Filename: {filename}")
        sys.exit(0)  # Using sys.exit() with OITC status code for OK
    else:
        # If the file for the current date is not found, check the latest backup file.
        latest_file = get_latest_backup_file(host, backup_dir)

        if latest_file:
            # Check if the latest file was written in the last 24 hours.
            file_age = datetime.datetime.now() - datetime.datetime.fromtimestamp(os.path.getmtime(latest_file))
            if file_age.total_seconds() <= 26 * 60 * 60:  # 24 hours in seconds
                # If the latest file is found and is less than 24 hours old, print an "OK" message with the latest file details.
                print(f"OK - The full backup file for {host} was found from the previous day in less than 24hrs. Latest Filename: {os.path.basename(latest_file)}")
                sys.exit(0)  # Using sys.exit() with OITC status code for OK
            else:
                # If the latest file is found but older than 24 hours, print a "CRITICAL" message with the latest file details.
                print(f"CRITICAL - Full backup file for {host} not found or not updated in the last 24 hours. Latest Filename: {os.path.basename(latest_file)}")
                sys.exit(2)  # Using sys.exit() with OITC status code for CRITICAL
        else:
            # If neither the expected backup file nor the latest backup file is found, print a "CRITICAL" message with the expected filename.
            print(f"CRITICAL - Full backup file for {host} not found or not updated in the last 24 hours. Expected Filename: {filename}")
            sys.exit(2)  # Using sys.exit() with OITC status code for CRITICAL


def get_latest_backup_file(host, backup_dir):
    """Get the latest backup file for the given host from the backup directory."""
    # Get a list of all backup files with the given host prefix.
    files = [f for f in os.listdir(backup_dir) if f.startswith(host + "_") and f.endswith(".ucs")]

    if not files:
        return None

    # LAMBDA fun- Sort the files by modification time (most recent first order).
    files.sort(key=lambda f: os.path.getmtime(os.path.join(backup_dir, f)), reverse=True)

    return os.path.join(backup_dir, files[0])


if __name__ == "__main__":
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Check if a .ucs backup file exists for the given host.")
    parser.add_argument("-host", dest="host", type=str, help="Hostname for which to check the backup file. eg : check_f5_full_backup -host <HOSTNAME>", required=True)
    args = parser.parse_args()

    # Check the backup file for the provided host
    check_backup_file(args.host)
