import subprocess

# read list of hostnames from file
with open('hostnames.txt', 'r') as f:
    hostnames = [line.strip() for line in f.readlines()]

# perform nslookup for each hostname
for hostname in hostnames:
    result = subprocess.run(['nslookup', hostname], capture_output=True, text=True)
    if result.returncode == 0:
        # extract IP address from output
        ip_address = result.stdout.split('Address: ')[-1].split()[0]
        print(f'{hostname}: {ip_address}')
    else:
        print(f'Error looking up {hostname}')
