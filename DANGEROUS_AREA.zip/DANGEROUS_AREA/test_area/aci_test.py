import json
import requests
from requests.packages import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ACI controller credentials
aci_credentials = {
    "dcdelb1nc10001-1.mn-man.biz": {
        "username": "apic#Local\\ncm-backup",
        "password": "Cisco.123"
    },
    "dcdelb1nc10002-1.mn-man.biz": {
        "username": "apic#Local\\ncm-backup",
        "password": "Cisco.123"
    }
}

# Define the REST API endpoint
backup_endpoint = "https://{}/api/node/mo/uni/fabric/configexp-defaultOneTime.json"

# Define the payload for the backup operation
backup_payload = {
  "configExportP": {
    "attributes": {
      "dn": "uni/fabric/configexp-defaultOneTime",
      "name": "defaultOneTime",
      "snapshot": "false",
      "targetDn": "",
      "adminSt": "triggered",
      "rn": "configexp-defaultOneTime",
      "status": "created,modified",
      "descr": "Test-Snapshot-for NCM"
    },
    "children": [
      {
        "configRsRemotePath": {
          "attributes": {
            "tnFileRemotePathName": "ConfigManager-SCP",
            "status": "created,modified"
          },
          "children": []
        }
      }
    ]
  }
}

# Create a session to persist the authentication
session = requests.Session()

# Loop over the ACI controllers
for aci_host, aci_creds in aci_credentials.items():
    # APIC IP address and credentials
    apic_ip = aci_host
    username = aci_creds["username"]
    password = aci_creds["password"]
    
    # Format the backup endpoint URL with the APIC IP address
    endpoint_url = backup_endpoint.format(apic_ip)

    # Send the login request
    login_endpoint = "https://{}/api/aaaLogin.json".format(apic_ip)
    login_payload = {
        "aaaUser": {
            "attributes": {
                "name": username,
                "pwd": password
            }
        }
    }
    response = session.request("POST", login_endpoint, data=json.dumps(login_payload), headers={'content-type': 'application/json'}, verify=False)

    # Check if the login was successful
    if response.status_code == 200:
        # Send the backup request
        response = session.request("POST", endpoint_url, data=json.dumps(backup_payload), headers={'content-type': 'application/json'}, verify=False)

        # Check if the backup was successful
        if response.status_code == 200:
            print("Backup Successful for {}".format(apic_ip))
        else:
            print("Backup Failed for {}".format(apic_ip))
    else:
        print("Login Failed for {}".format(apic_ip))

    # Logout from the APIC
    logout_endpoint = "https://{}/api/aaaLogout.json".format(apic_ip)
    response = session.request("POST", logout_endpoint, headers={'content-type': 'application/json'}, verify=False)