#!/bin/bash

#set -x

f5_hosts="IBDDWFXHIA67394 IBDMWFXHIA67393 IBDDWFXHPA64689 IBDMWFXHPA64690"
backup_user="f5backup"
date=$(date +%Y%m%d)
target_dir="/shared/backups"
backup_dir="/NCM/backup"

for f5_host in ${f5_hosts}
do
    ucs_file="${f5_host}_${date}.ucs"
    /usr/bin/ssh -i /manhome/MANUSER/y6857/.ssh/.f5key -q -x -l "${backup_user}" "${f5_host}" "tmsh save /sys ucs \"${target_dir}/${ucs_file}\""
    /usr/bin/scp -i /manhome/MANUSER/y6857/.ssh/.f5key "${backup_user}@${f5_host}:${target_dir}/${ucs_file}" "${backup_dir}"
    /usr/bin/ssh -i /manhome/MANUSER/y6857/.ssh/.f5key -q -x -l "${backup_user}" "${f5_host}" "rm \"${target_dir}/${ucs_file}\""
done

find "${backup_dir}" -type f -mtime +30 -delete


#This shell script for performing a backup of F5 BIG-IP systems. The script does the following:

# Declares a list of F5 BIG-IP hostnames in the "f5_hosts" variable.
# Declares the username for logging into the F5 BIG-IP systems in the "backup_user" variable.
# Sets the date in the "date" variable using the date command.
# Declares the target directory on the F5 BIG-IP systems in the "target_dir" variable.
# Declares the backup directory on the local system in the "backup_dir" variable.
# The script then enters a loop where it performs the following steps for each of the F5 BIG-IP hosts in the "f5_hosts" list:
# Sets the name of the backup file in the "ucs_file" variable.
# Uses the "ssh" command to log into the F5 BIG-IP system and run the "tmsh save /sys ucs" command to save a backup of the system configuration. The backup file is saved in the "target_dir" on the F5 BIG-IP system.
# Uses the "scp" command to copy the backup file from the F5 BIG-IP system to the "backup_dir" on the local system.
# Uses the "ssh" command to log into the F5 BIG-IP system and delete the backup file from the "target_dir".
# Finally, the script uses the "find" command to delete any backup files in the "backup_dir" that are older than 30 days.