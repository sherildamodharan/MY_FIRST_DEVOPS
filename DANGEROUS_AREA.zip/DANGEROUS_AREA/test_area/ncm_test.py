import sys
import socket
import requests
import argparse
import json
from requests.packages import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Help 
parser = argparse.ArgumentParser(description='Check ManageEngine NCM device backup status')
parser.add_argument('-host', '-HOST', dest='host', type=str, help='Provide the Hostname of the device eg : oitc_ncm_device_backup_status.py -host <HOSTNAME>', required=True)
parser.add_argument('-key', '-KEY', dest='key', type=str, help='Provide the API KEY of NCM eg : oitc_ncm_device_backup_status.py -host <HOSTNAME> -key <API-KEY>', required=True )
args = parser.parse_args()

api_endpoint = "https://is-config-manager.mn-man.biz"
# API endpoint URL
url = api_endpoint+"/api/json/v2/ncmdevice/listAllDevices"

# API key
api_key = args.key
# host_name = "mndeklirt10200.mn-man.biz"
host_name = args.host

# Filters
filters = {"groupOp": "AND", "rules": [{"field": "NCMDevices__RESOURCENAME", "op": "cn", "data": str(host_name)}]}

try:
    # Make GET request to API endpoint
    response = requests.get(url, params={"apiKey": str(api_key), "jqgridLoad": "true", "filters": json.dumps(filters)}, verify=False, timeout= 50)
    response.raise_for_status()
except requests.exceptions.HTTPError as errh:
    print ("HTTP Error:",errh)
    sys.exit(2)
except requests.exceptions.ConnectionError as errc:
    print ("Error Connecting:",errc)
    sys.exit(2)
except requests.exceptions.Timeout as errt:
    print ("Timeout Error:",errt)
    sys.exit(2)
except requests.exceptions.RequestException as err:
    print ("Something went wrong:",err)
    sys.exit(2)

# Parse JSON response
data = json.loads(response.text)

# API Key error handling
if 'error' in data and data['error']['code'] == 5000:
    print("WARNING: Invalid API Key")
    exit(2)

# Extract device ID & Invalid hostname handling
if not data["rows"]:
    print("Invalid Hostname - Please verify the hostname & match with NCM")
    sys.exit(1)
else:
    device_id = data["rows"][0]["id"]
    # Try to resolve hostname to IP address
    try:
        ip_address = socket.gethostbyname(host_name)
    except socket.gaierror:
        ip_address = None
    # If IP address is found, update the filter to use it
    if ip_address:
        filters = {"groupOp": "AND", "rules": [{"field": "NCMDevices__IPADDRESS", "op": "eq", "data": str(ip_address)}]}


backup_info = {}
backup_url = api_endpoint + "/api/json/ncmdevice/devSummary?apiKey="+api_key+"&deviceId="+str(device_id)
try:
    response = requests.get(backup_url, verify=False, timeout=10)
    response.raise_for_status()
except requests.exceptions.HTTPError as errh:
    print ("HTTP Error:",errh)
    sys.exit(2)
except requests.exceptions.ConnectionError as errc:
    print ("Error Connecting:",errc)
    sys.exit(2)
except requests.exceptions.Timeout as errt:
    print ("Timeout Error:",errt)
    sys.exit(2)
except requests.exceptions.RequestException as err:
    print ("Something went wrong:",err)
    sys.exit(2)

backup_data = json.loads(response.text)["devDetails"]

# Parsing response to get backup status
backup_status = response.json()["devDetails"]
backup_info[device_id] = backup_data

# Decision making - Critical if backup failed | Ok - if backup success
if backup_data["LastOperationStatus"] == "FAILURE":
    print("CRITICAL- Backup Failure. The last successful backup was on ", backup_data["LastSuccessfulOperationAt"])
    sys.exit(2)
else:
    print("OK- Last backup successful on ", backup_data["LastSuccessfulOperationAt"])
    sys.exit(0)


