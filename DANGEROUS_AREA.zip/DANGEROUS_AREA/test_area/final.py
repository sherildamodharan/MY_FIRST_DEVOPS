#!/usr/bin/env python3
"""Script for checking NCM for the last backup"""

import sys
import json
import argparse
import requests

# Disable SSL warning
requests.urllib3.disable_warnings()
# Help script
parser = argparse.ArgumentParser(description='Check ManageEngine NCM device backup status')
parser.add_argument('-host', '-HOST', dest='host', type=str, help='Provide the Hostname of the device eg : oitc_ncm_device_backup_status.py -host <HOSTNAME>', required=True)
parser.add_argument('-key', '-KEY', dest='key', type=str, help='Provide the API KEY of NCM eg : oitc_ncm_device_backup_status.py -host <HOSTNAME> -key <API-KEY>', required=True)
parser.add_argument('-d', '--diagnose', dest='diagnose', action='store_true', help='Display full error message for debugging purposes')
args = parser.parse_args()

# API endpoint URL
API_ENDPOINT = "https://is-config-manager.mn-man.biz"
URL = f"{API_ENDPOINT}/api/json/v2/ncmdevice/listAllDevices"

# API key
api_key = args.key

# Hostname
host_name = args.host

# Filters
filters = {
    "groupOp": "AND",
    "rules": [
        {
            "field": "NCMDevices__RESOURCENAME",
            "op": "cn",
            "data": str(host_name)
        }
    ]
}

try:
    # Make GET request to API endpoint
    response = requests.get(
        URL,
        params={
            "apiKey": str(api_key),
            "jqgridLoad": "true",
            "filters": json.dumps(filters)
        },
        verify=False,
        timeout=20
    )
    response.raise_for_status()
except requests.exceptions.HTTPError as error:
    print("UNKNOWN HTTP Error")
    if args.diagnose:
        print(error.response.text)
    sys.exit(3)
except requests.exceptions.ConnectionError as error:
    print("UNKNOWN - Error Connecting")
    if args.diagnose:
        print(error)
    sys.exit(3)
except requests.exceptions.Timeout as error:
    print("UNKNOWN - Timeout Error")
    if args.diagnose:
        print(error)
    sys.exit(3)
except requests.exceptions.RequestException as error:
    print("Something went wrong")
    if args.diagnose:
        print(error)
    sys.exit(3)

# Parse JSON response
data = json.loads(response.text)

# API Key error handling
if 'error' in data and data['error']['code'] == 5000:
    print("WARNING: Invalid API Key")
    sys.exit(2)

# Extract device ID & Invalid hostname handling
if not data["rows"]:
    print("Invalid Hostname - Please verify the hostname & match with NCM")
    sys.exit(1)
else:
    device_id = data["rows"][0]["id"]
backup_info = {}
# Backup URL
BACKUP_URL = f"{API_ENDPOINT}/api/json/ncmdevice/devSummary?apiKey={api_key}&deviceId={device_id}"
try:
    response = requests.get(BACKUP_URL, verify=False, timeout=10)
    response.raise_for_status()
except requests.exceptions.HTTPError as error:
    print("UNKNOWN HTTP Error")
    if args.diagnose:
        print(error.response.text)
    sys.exit(3)
except requests.exceptions.ConnectionError as error:
    print("UNKNOWN - Error Connecting")
    if args.diagnose:
        print(error)
    sys.exit(3)
except requests.exceptions.Timeout as errt:
    print("UNKNOWN - Timeout Error")
    if args.diagnose:
        print(errt)
    sys.exit(3)
except requests.exceptions.RequestException as err:
    print("Something went wrong")
    if args.diagnose:
        print(err)
    sys.exit(3)

backup_data = json.loads(response.text)["devDetails"]

# Parsing response to get backup status
backup_status = response.json()["devDetails"]
backup_info[device_id] = backup_data

# Decision making - Critical if backup failed | Ok - if backup success
if backup_data["LastOperationStatus"] == "FAILURE":
    print("CRITICAL- Backup Failure. The last successful backup was on ", backup_data["LastSuccessfulOperationAt"])
    sys.exit(2)
else:
    print("OK- Last backup successful on ", backup_data["LastSuccessfulOperationAt"])
    sys.exit(0)