#!/usr/bin/env python3


"""
This plugin verifies that the F5-full backup files are being stored/written on the FIOBC-SEC probe on a regular basis
USAGE:
python3 test.py -host IBDDWFXHPA64689
OK - The full backup file for IBDDWFXHPA64689 has been backed up successfully.
python3 test.py -host IBDDWFXHPA64681
CRITICAL - Full backup file for IBDDWFXHPA64681 not found.
"""


import argparse
import os
import datetime

def check_backup_file(host):
    # Define the backup directory
    backup_dir = "/NCM/backup/"

    # Get the current date in the format 'YYYYMMDD'
    current_date = datetime.datetime.now().strftime("%Y%m%d")

    # Create the expected filename based on the provided host and current date
    filename = f"{host}_{current_date}.ucs"

    full_path = os.path.join(backup_dir, filename)

    if os.path.exists(full_path):
        print(f"OK - The full backup file for {host} has been backed up successfully. Filename:{filename}")
        exit(0)  # OITC status code for OK
    else:
        print(f"CRITICAL - Full backup file for {host} not found. Expected Filename:{filename}")
        exit(2)  # OITC status code for CRITICAL

if __name__ == "__main__":
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Check if a .ucs backup file exists for the given host.")
    parser.add_argument("-host", dest="host", type=str, help="Hostname for which to check the backup file. eg : check_f5_full_backup -host <HOSTNAME>", required=True)
    args = parser.parse_args()

    # Check the backup file for the provided host
    check_backup_file(args.host)
