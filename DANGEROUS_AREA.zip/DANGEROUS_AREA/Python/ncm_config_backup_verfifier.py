import os
import time

base_directory = '/opt/ManageEngine/NCMCentral/config_backup'
latest_directory = max([d for d in os.listdir(base_directory) if os.path.isdir(os.path.join(base_directory, d))], key=lambda x: os.path.getmtime(os.path.join(base_directory, x)))
print("Latest Directory is :{}".format(latest_directory))
directory = os.path.join(base_directory, latest_directory)

for filename in os.listdir(directory):
    if filename.endswith('.txt'):
        filepath = os.path.join(directory, filename)
        with open(filepath) as f:
            lines = f.readlines()
            if len(lines) < 10:
               # print(f'{filename} has less than 10 lines of text.')
                print("{} -has less than 10 lines".format(filename))
            else:
                print("{} -OK".format(filename))

