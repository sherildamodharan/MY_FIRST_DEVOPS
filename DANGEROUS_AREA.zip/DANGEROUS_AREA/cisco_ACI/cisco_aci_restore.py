import requests
import json
from requests.packages import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Define the IP address of the APIC and the authentication credentials
apic_ip = "10.132.152.11"
username = "apic#Local\\ncm-backup"
password = "Cisco.123"

# Define the headers to be used in the API requests
headers = {'Content-Type': 'application/json'}

# Define the payload for the first API call to create the configuration snapshot
snapshot_payload = {
    "fabricInst": {
        "attributes": {
            "dn": "uni/fabric",
            "status": "created,modified"
        },
        "children": [
            {
                "configSnapshotMgrP": {
                    "attributes": {
                        "dn": "uni/fabric/snpmgr-default",
                        "name": "default",
                        "adminSt": "triggered",
                        "fileName": "ce2_defaultOneTime-2022-07-19T14-02-44.tar.gz",
                        "mode": "download",
                        "rn": "snpmgr-default",
                        "status": "created,modified"
                    },
                    "children": [
                        {
                            "configRsRemotePath": {
                                "attributes": {
                                    "tnFileRemotePathName": "ConfigManager-SCP",
                                    "status": "created,modified"
                                },
                                "children": []
                            }
                        }
                    ]
                }
            }
        ]
    }
}

# Define the payload for the second API call to import the configuration snapshot
import_payload = {
    "configImportP": {
        "attributes": {
            "dn": "uni/fabric/configimp-default",
            "name": "default",
            "snapshot": "true",
            "adminSt": "triggered",
            "fileName": "ce2_default-2022-07-19T14-09-38.tar.gz",
            "importType": "replace",
            "importMode": "atomic",
            "rn": "configimp-default",
            "status": "created,modified"
        },
        "children": []
    }
}

# Define the URLs for the API calls
snapshot_url = f"https://{apic_ip}:8003/api/node/mo/uni/fabric.json"
import_url = f"https://{apic_ip}:8003/api/node/mo/uni/fabric/configimp-default.json"

# Make the first API call to create the configuration snapshot
response = requests.post(snapshot_url, headers=headers, auth=(username, password), data=json.dumps(snapshot_payload), verify=False)

# Print the API response
print(f"Create snapshot API response: {response.text}")

# Make the second API call to import the configuration snapshot
response = requests.post(import_url, headers=headers, auth=(username, password), data=json.dumps(import_payload), verify=False)

# Print the API response
print(f"Import snapshot API response: {response.text}")
