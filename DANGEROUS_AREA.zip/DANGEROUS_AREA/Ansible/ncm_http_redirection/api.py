
import requests

url = "https://is-config-manager.mn-man.biz/api/json/ncmdevice/listAllDevices?apiKey=d407b59cc111b42a7f95089626612f47"

payload={}
headers = {
  'Cookie': 'JSESSIONID=07BFCAEDBD82AA2A97DA71317F4DAE71; _zcsr_tmp=3787541bc1b429cb13496c66d081e1bd866b29f025094a95d74ed797b804117378068ee9a1ac5df4d8d0ca14ce2833a5ec4ec1e3b42953a32b9ef7c791d3b12d; opmcsrfcookie=3787541bc1b429cb13496c66d081e1bd866b29f025094a95d74ed797b804117378068ee9a1ac5df4d8d0ca14ce2833a5ec4ec1e3b42953a32b9ef7c791d3b12d'
}

response = requests.request("GET", url, headers=headers, data=payload, verify=False)

# print(response.json())

#failed = response.json()["rows"][1]["cell"]
#print(failed)
# print(response.text)
string = response.text
print('Number of devices backedup successfully:', string.count('Backup__SUCCESS'))
print('Number of devices with Backup failure:', string.count('Backup__FAILURE'))



#for i in response.json()["rows"]["cell"]:
    
    # print(i['cell'])
