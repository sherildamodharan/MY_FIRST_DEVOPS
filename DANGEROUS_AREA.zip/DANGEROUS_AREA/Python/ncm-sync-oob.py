#!/bin/env python

import os
import logging
from datetime import date
import glob

host = "mbddmorppa09444"  # Please change the destinantion host name here

path = "/opt/ManageEngine/NCMCentral/config_backup/"
dest = "/opt/systembackup/ncm_config_backup/"
logfile = "/opt/ManageEngine/scripts/NCM_rsync.txt"

# Use glob to get the latest directory in the base directory
latest_dir = max(glob.glob(path + '*'), key=os.path.getctime)
fileCounter = len(glob.glob1((latest_dir),"*.txt"))
# print(fileCounter)

# testing the script here.
#with open("{}".format(logfile), "a") as f:
#        f.write("*****Sync starting*****")


# if the new directory is not found, print on screen. Else run rsync
if os.path.exists(latest_dir) == True:
    ssh_key = "/manhome/MANUSER/l2954/.ssh/id_rsa_opsal-ncm-oob-sync" # change this to the path of your ssh key
    rsync_command = "rsync -avz -e 'ssh -i {}' {} opsal@{}:{}".format(ssh_key, latest_dir, host, dest)
    rsync_result = os.system(rsync_command)
#    print(rsync_result)
    if rsync_result != 0:
        with open("{}".format(logfile), "a") as f:
            f.write("ERROR- rsync command failed with error code {} at {}\n".format(rsync_result, date.today()))
    else:
        with open("{}".format(logfile), "a") as f:
            f.write("OK-File sync successfull at {} & {} files transfered\n".format(date.today(), fileCounter))
else:
    with open("{}".format(logfile), "a") as f:
        f.write("WARNING-Latest backup directory {} not found at {}\n".format(latest_dir, date.today()))