#!/usr/bin/env python3
"""
This is a Python script that checks the device scan status and port usage of a network device. 
It takes the device hostname and API-key as arguments and returns the result.
"""
import argparse
import sys
import requests
from requests.packages import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def get_device_status_and_usage(device_name, api_key):
    """Get the device scan status and usage from the API and return the result as a string"""
    URL = 'https://is-oputils.mn-man.biz/api/json/spm/getAllSwitchesSummary'
    params = {
        'groupId': 'SPMGROUP_0',
        '_search': 'true',
        'nd': '1675943531802',
        'rows': 100,
        'page': 1,
        'sortByColumn': 'switch-name',
        'sortByType': 'asc',
        'filters': '{"groupOp":"AND","rules":[{"field":"switch-name","op":"cn","data":"' + device_name + '"}]}',
        'apiKey': api_key
    }

    try:
        response = requests.get(URL, params=params, verify=False, timeout=200)
        response.raise_for_status()
        response_json = response.json()

        if 'error' in response_json:
            print("UNKNOWN: Please verify the APIKey")
            sys.exit(3)
        if 'rows' not in response_json:
            return "UNKNOWN: Key 'rows' not found in response JSON"

        for device in response_json['rows']:
            if device['switch-name'] == device_name:
                scan_status = device['scan-status']
                if scan_status == "Failed":
                    print(f"WARNING: {device_name} scan status is Failed on OpUtils")
                    sys.exit(3)
                elif scan_status == "Scanned":
                    used_percentage = device['usedPercentage']
                    if used_percentage > 90:
                        print(f"CRITICAL: PORT Usage of {device_name} is at {used_percentage}% usage")
                        sys.exit(2)
                    else:
                        print(f"OK: PORT usage of {device_name} is at {used_percentage}% usage")
                        sys.exit(0)
        print(f"UNKNOWN: device {device_name} not found")
        sys.exit(3)
    except requests.exceptions.HTTPError as err:
        print(f"OK: {err}")
        sys.exit(0)
    except requests.exceptions.ConnectionError as err:
        print(f"OK: {err}")
        sys.exit(0)
    except requests.exceptions.RequestException as err:
        print(f"OK: {err}")
        sys.exit(0)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Check the Device Scan Status and Port Usage status from OpUtils')
    parser.add_argument('-H', '--hostname', required=True, help='Device hostname is required')
    parser.add_argument('-K', '--apikey', required=True, help='API key is required')
    args = parser.parse_args()
    result = get_device_status_and_usage(args.hostname, args.apikey)
    print(result)
