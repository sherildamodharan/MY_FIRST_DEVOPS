#!/bin/bash

# Set the location of the script
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

# Name of the log file
log_file="${SCRIPT_DIR}/f5_backup_log.txt"

#set -x

f5_hosts="IBDDWFXHIA67394 IBDMWFXHIA67393 IBDDWFXHPA64689 IBDMWFXHPA64690"
backup_user="f5backup"
date=$(date +%Y%m%d)
target_dir="/shared/backups"
backup_dir="/NCM/backup"

# Function to log the filename
log_filename() {
    echo "$(date) - $1" >> "${log_file}"
}

for f5_host in ${f5_hosts}
do
    ucs_file="${f5_host}_${date}.ucs"
    /usr/bin/ssh -i /manhome/MANUSER/y6857/.ssh/.f5key -q -x -l "${backup_user}" "${f5_host}" "tmsh save /sys ucs \"${target_dir}/${ucs_file}\""
    /usr/bin/scp -i /manhome/MANUSER/y6857/.ssh/.f5key "${backup_user}@${f5_host}:${target_dir}/${ucs_file}" "${backup_dir}"
    /usr/bin/ssh -i /manhome/MANUSER/y6857/.ssh/.f5key -q -x -l "${backup_user}" "${f5_host}" "rm \"${target_dir}/${ucs_file}\""

    # Log the filename in the log file
    log_filename "${ucs_file}"
done

find "${backup_dir}" -type f -mtime +30 -delete
