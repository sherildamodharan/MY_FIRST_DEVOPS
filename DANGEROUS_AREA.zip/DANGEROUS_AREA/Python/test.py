import paramiko

# Change these values to match your remote server's SSH credentials
hostname = 'mbdcasrvpb38119.mn-man.biz'
port = 22
username = 'l2954'
password = 'RTix+CheBgW7L0mk#12d'

# Create an SSH client object
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

# Connect to the remote server
ssh.connect(hostname, port=port, username=username, password=password)

# Run the command to get into the "get-root-shell" room
stdin, stdout, stderr = ssh.exec_command('tmux send-keys -t get-root-shell "RTix+CheBgW7L0mk#12d" Enter')

# Wait for the command to finish
stdout.channel.recv_exit_status()

# Use SCP to copy the file to the local machine
sftp = ssh.open_sftp()
sftp.get('/etc/elasticsearch/elasticsearch.yml', './elasticsearch.yml')
sftp.close()

# Close the SSH connection
ssh.close()
