import requests
# API URL
url = "https://is-config-manager.mn-man.biz/api/json/v2/ncmdevice/listAllDevices?apiKey=d407b59cc111b42a7f95089626612f47"

# Define payload and headers
payload={}
headers = {
  'Cookie': 'JSESSIONID=DC21FFC8F3C6A78360BDAE67E6A47FCE; _zcsr_tmp=8874a95a41a77d327d9f2e0579705c521bc943e3a90686199213707264cd4d68d3b615adc09ce843d5355e4ed6239b42fc7bba4831de9a68f27ad7e1e41e6d8e; opmcsrfcookie=8874a95a41a77d327d9f2e0579705c521bc943e3a90686199213707264cd4d68d3b615adc09ce843d5355e4ed6239b42fc7bba4831de9a68f27ad7e1e41e6d8e'
}

# API call
response = requests.get(url, headers=headers, data=payload, verify=False, timeout=10)

# If 200 OK- continue to the next steps, else break
if response.status_code:
    data = response.json()
    failed = 0
    success = 0
#data = json.load(response)

    for p in data['rows']:
        print('HostName: ' + p['RESOURCENAME'] + " - " + 'Backupstatus: ' + p['BACKUP_STATUS'])
        if p['BACKUP_STATUS'] == "FAILURE":
            failed = failed+1
        elif p['BACKUP_STATUS'] == "SUCCESS":
            success = success+1
    # else:
      # print("Unknown")

# Pulling the total number of devices from the json objects
    total = response.json()["records"]
    print("Total number of devices:", total)
# print the SUCCESS & FAILURE
    print("Total backup successful:", success)

    print("Total failed Backups:", failed)

# Matching the success and failed against total to verify all objects are covered
    if int(failed)+int(success)==int(total):
      print("Objects are matching")
      exit(0)
    else:
      print("Total Objects doesnt match with the objects counted")
      exit(2)
else:
  print(f"Issues with API connection {response.status_code}")
  exit(2)

