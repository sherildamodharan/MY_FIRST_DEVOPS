"""
This code is used to trigger the backup/snapshot from the CISCO ACI controllers and push to the NCM server through SFTP.

"""

import json
import requests
from requests.packages import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# APIC IP address and credentials
apic_ip = "10.132.152.11"
username = "apic#Local\\ncm-backup"
password = "Cisco.123"

# Define the REST API endpoint
backup_endpoint = "https://" + apic_ip + "/api/node/mo/uni/fabric/configexp-defaultOneTime.json"

# Define the payload for the backup operation
backup_payload = {
  "configExportP": {
    "attributes": {
      "dn": "uni/fabric/configexp-defaultOneTime",
      "name": "defaultOneTime",
      "snapshot": "false",
      "targetDn": "",
      "adminSt": "triggered",
      "rn": "configexp-defaultOneTime",
      "status": "created,modified",
      "descr": "Test-Snapshot-for NCM"
    },
    "children": [
      {
        "configRsRemotePath": {
          "attributes": {
            "tnFileRemotePathName": "ConfigManager-SCP",
            "status": "created,modified"
          },
          "children": []
        }
      }
    ]
  }
}

# Create a session to persist the authentication
session = requests.Session()

# Login to the APIC
login_endpoint = "https://" + apic_ip + "/api/aaaLogin.json"
login_payload = {
  "aaaUser": {
    "attributes": {
      "name": username,
      "pwd": password
    }
  }
}

# Send the login request
response = session.request("POST", login_endpoint, data=json.dumps(login_payload), headers={'content-type': 'application/json'}, verify=False)

# Check if the login was successful
if response.status_code == 200:
  # Send the backup request
    response = session.request("POST", backup_endpoint, data=json.dumps(backup_payload), headers={'content-type': 'application/json'}, verify=False)
    # print(response)
  # Check if the backup was successful
    if response.status_code == 200:
        print("Backup Successful")
    else:
        print("Backup Failed")
else:
    print("Login Failed")

# Logout from the APIC
logout_endpoint = "https://" + apic_ip + "/api/aaaLogout.json"
response = session.request("POST", logout_endpoint, headers={'content-type': 'application/json'}, verify=False)
