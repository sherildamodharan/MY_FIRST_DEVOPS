#!/bin/bash

LOG_DIR="/opt/ManageEngine/NCMProbe/config_backup"
DAYS_TO_KEEP=60

# check if destination folder exists and is a folder
[[ -d "${LOG_DIR}" ]] || exit 1

# delete files older than ${DAYS_TO_KEEP} days
find "${LOG_DIR}" -type f -mtime +"${DAYS_TO_KEEP}" -delete 2>&1

# delete empty directories older than ${DAYS_TO_KEEP} days
find "${LOG_DIR}" -type d -mtime +"${DAYS_TO_KEEP}" -empty -delete 2>&1


# crontab -e
# 0 4 * * * /path/to/your/script.sh  -> 4AM everyday
