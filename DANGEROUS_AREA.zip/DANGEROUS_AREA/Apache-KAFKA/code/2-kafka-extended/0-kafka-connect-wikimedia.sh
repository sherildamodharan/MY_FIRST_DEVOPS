connect-standalone.sh config/connect-standalone.properties config/wikimedia.properties


# Sample data returned in 
# 0-kafka-connect-wikimedia-sample.json