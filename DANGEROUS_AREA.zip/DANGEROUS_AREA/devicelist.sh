#!/bin/bash

 

APIKEY="d407b59cc111b42a7f95089626612f47"

 

templates="$(curl "https://is-config-manager.mn-man.biz/api/json/v2/ncmdevice/deviceTemplates?apiKey=${APIKEY}" 2>/dev/null | jq -r '.rows[].id')"
for templateid in $(echo "${templates}") ; do
    template="$(curl "https://is-config-manager.mn-man.biz/api/json/ncmsettings/exportDeviceTemplate?DEVICETEMPLATEID=${templateid}&apiKey=${APIKEY}" 2>/dev/null)"
    # echo "template is ${template}"
    name="$(echo "${template}" | head | sed -ne's/.*NCMDeviceTemplate.*displayName="\([^"]*\).*/\1/p' | sed -e's#/#-#g')"
    echo "got template ${name}"
    echo "${template}" > "${name}".xml
done