#!/usr/bin/env python3
import json
import sys
import requests
import argparse
from requests.packages import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

parser = argparse.ArgumentParser(description='Check ManageEngine NCM Total device backup status')
parser.add_argument('-key', '-KEY', dest='key', type=str, help='Provide the API KEY of NCM eg : check_ncm_all_device_backup_status.py -key <API-KEY>', required=True )
args = parser.parse_args()
# API URL and key
api_key = args.key
url = f"https://is-config-manager.mn-man.biz/api/json/v2/ncmdevice/listAllDevices?apiKey={api_key}"

# Define headers
headers = {}

try:
    # Make API call
    response = requests.get(url, headers=headers, verify=False, timeout=10)

    # Check if the status code is 200 OK
    response.raise_for_status()
    
    #if response.status_code == 5000:  
    data = response.json()

    # Invalid API Key handling
    if 'error' in data and data['error']['code'] == 5000:
        print("WARNING: Invalid API Key")
        exit(2)
    failed = 0
    success = 0

    # Iterate through the data
    for p in data['rows']:
        if p['BACKUP_STATUS'] == "FAILURE":
            failed += 1
        elif p['BACKUP_STATUS'] == "SUCCESS":
            success += 1

    # Get the total number of devices
    total = data["records"]

    # Check if total devices is 0
    if total == 0:
        print("Critical-No devices found")
        exit(2)

    # Check if the number of failed backups is more than 25% of total
    if int(failed) / int(total) * 100 < 25:
        print(f"OK-Total_Devices:{total} | Backups_Successfull:{success} | Backups_failed:{failed}")
        exit(0)
    else:
        print(f"CRITICAL- Number of failed backups:{failed} are more than 25% of the total:{total}")
        exit(2)

except requests.exceptions.HTTPError as errh:
    print ("HTTP Error:",errh)
    sys.exit(2)
except requests.exceptions.ConnectionError as errc:
    print ("Error Connecting:",errc)
    sys.exit(2)
except requests.exceptions.Timeout as errt:
    print ("Timeout Error:",errt)
    sys.exit(2)
except requests.exceptions.RequestException as err:
    print ("Something went wrong:",err)
    sys.exit(2)
