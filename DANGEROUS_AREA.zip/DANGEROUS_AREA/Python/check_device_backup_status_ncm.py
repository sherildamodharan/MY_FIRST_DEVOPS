#!/usr/bin/env python3

import sys
import requests
import argparse
import json
from requests.packages import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Help 
parser = argparse.ArgumentParser(description='Check ManageEngine NCM device backup status')
parser.add_argument('-host', '-HOST', dest='host', type=str, help='Provide the Hostname of the device eg : oitc_ncm_device_backup_status.py -host <HOSTNAME>', required=True)
parser.add_argument('-key', '-KEY', dest='key', type=str, help='Provide the API KEY of NCM eg : oitc_ncm_device_backup_status.py -host <HOSTNAME> -key <API-KEY>', required=True )
args = parser.parse_args()

api_endpoint = "https://is-config-manager.mn-man.biz"
# API endpoint URL
url = api_endpoint+"/api/json/v2/ncmdevice/listAllDevices"

api_key = args.key
host_name = args.host

# Filters
filters = {"groupOp": "AND", "rules": [{"field": "NCMDevices__RESOURCENAME", "op": "cn", "data": str(host_name)}]}

try:
    # Make GET request to API endpoint
    response = requests.get(url, params={"apiKey": str(api_key), "jqgridLoad": "true", "filters": json.dumps(filters)}, verify=False)
    response.raise_for_status()
except requests.exceptions.HTTPError as errh:
    print ("HTTP Error:",errh)
    sys.exit(2)
except requests.exceptions.ConnectionError as errc:
    print ("Error Connecting:",errc)
    sys.exit(2)
except requests.exceptions.Timeout as errt:
    print ("Timeout Error:",errt)
    sys.exit(2)
except requests.exceptions.RequestException as err:
    print ("Something went wrong:",err)
    sys.exit(2)

# Parse JSON response
data = json.loads(response.text)

# Extract device ID
if not data["rows"]:
    print("UNKNOWN Hostname - Please verify the hostname & match with NCM")
    sys.exit(3)
else:
    device_id = data["rows"][0]["id"]
#    print("Device ID:", device_id)   # Final Device ID

backup_info = {}
backup_url = api_endpoint + "/api/json/ncmdevice/devSummary?apiKey="+api_key+"&deviceId="+str(device_id)
try:
    response = requests.get(backup_url, verify=False, timeout=10)
    response.raise_for_status()
except requests.exceptions.HTTPError as errh:
    print ("HTTP Error:",errh)
    sys.exit(2)
except requests.exceptions.ConnectionError as errc:
    print ("Error Connecting:",errc)
    sys.exit(2)
except requests.exceptions.Timeout as errt:
    print ("Timeout Error:",errt)
    sys.exit(2)
except requests.exceptions.RequestException as err:
    print ("Something went wrong:",err)
    sys.exit(2)

backup_data = json.loads(response.text)["devDetails"]

# Parsing response to get backup status
backup_status = response.json()["devDetails"]
backup_info[device_id] = backup_data

# Decision making - Critical if backup failed | Ok - if backup success
if backup_data["LastOperationStatus"] == "FAILURE":
    print("CRITICAL- Backup Failure. The last successful backup was on ", backup_data["LastSuccessfulOperationAt"])
    sys.exit(2)
else:
    print("OK- Last backup successful on ", backup_data["LastSuccessfulOperationAt"])
    sys.exit(0)

# d407b59cc111b42a7f95089626612f47