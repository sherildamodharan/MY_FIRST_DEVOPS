import socket

def get_hostname(ip_address):
    try:
        hostname, _, _ = socket.gethostbyaddr(ip_address)
        return hostname
    except socket.herror as e:
        return str(e)

def write_to_file(ip, hostname):
    with open("output.txt", "a") as f:
        f.write(f"{ip}:{hostname}\n")

with open("input.txt", "r") as f:
    for line in f:
        ip = line.strip()
        hostname = get_hostname(ip)
        write_to_file(ip, hostname)