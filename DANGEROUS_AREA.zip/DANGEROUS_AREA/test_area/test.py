# Array for fing the value

array = [-1, -4, -6, 6, -8, 2, 1]
zero_pairs = []

for i, num1 in enumerate(array):
    for _, num2 in enumerate(array[i+1:], start=i+1):
        if num1 + num2 == 0:
            zero_pairs.append((num1, num2))

print(zero_pairs)
