import xml.etree.ElementTree as ET
import csv
import os

def extract_data(xml_file, csv_file):
    tree = ET.parse(xml_file)
    root = tree.getroot()

    ncm_devices = root.findall(".//NCMDeviceSysOID")
    cust_devices = root.findall(".//CustDeviceSysOID")

    data = []
    for device in ncm_devices:
        model = device.get("model")
        ostype = device.get("ostype")
        series = device.get("series")
        sysoid = device.get("sysoid")
        data.append((xml_file, model, ostype, series, sysoid))

    for device in cust_devices:
        model = device.get("model")
        ostype = device.get("ostype")
        series = device.get("series")
        sysoid = device.get("sysoid")
        data.append((xml_file, model, ostype, series, sysoid))

    with open(csv_file, "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerows(data)

# Directory containing XML files
xml_directory = "/tmp/xml_extractor/Template/"
csv_file = "Templates.csv"

# Get a list of XML files in the directory
xml_files = [f for f in os.listdir(xml_directory) if f.endswith(".xml")]

# Write header row to CSV file
with open(csv_file, "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["template", "model", "ostype", "series", "sysoid"])

# Iterate through XML files and extract data
for xml_file in xml_files:
    xml_path = os.path.join(xml_directory, xml_file)
    extract_data(xml_path, csv_file)
