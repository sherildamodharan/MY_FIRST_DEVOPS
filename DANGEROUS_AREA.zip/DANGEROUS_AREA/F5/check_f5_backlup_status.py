#!/usr/bin/env python3

"""
F5 Backup Check Plugin

OITC plugin that fetches F5 backup information using the NCM Probe API and checks
if the latest backup file for a specific device was modified within the last 24 hours.

The script requires an API key for accessing the F5 backup API and the name of the device to filter
the latest backup information

Usage:
python script_name.py -apikey YOUR_API_KEY -device DEVICE_NAME

Requirements:
- Python 3.x
- requests library (install using 'pip install requests')

Exit Codes:
- 0: OK - The latest backup was modified within the last 24 hours.
- 2: CRITICAL - The latest backup was not modified within the last 24 hours or an error occurred.
- 3: UNKNOWN - Failed to retrieve F5 backup information.

"""

from datetime import datetime, timedelta
import sys
import argparse
import requests

# Argument parser
parser = argparse.ArgumentParser(description="Nagios plugin to fetch F5 backup information and check last modified time.")
parser.add_argument("-apikey", required=True, help="API key for accessing the F5 backup API.")
parser.add_argument("-device", required=True, help="Device name to filter the latest backup information.")
args = parser.parse_args()

api_key = args.apikey
device_name_to_filter = args.device

NCM_PROBE_ID = "IS_NCM_SEC1"

# Get F5 backup information using the NCM Probe API
url = f"https://is-config-manager.mn-man.biz/api/json/ncmsettings/getTFTPFiles?apiKey={api_key}&ncmProbeId={NCM_PROBE_ID}"
try:
    response = requests.get(url)
    backup_info = response.json()
except requests.exceptions.RequestException as error:
    print(f"Error occurred: {error}")
    sys.exit(2)  # Return critical status (exit code 2)

# Filter backup files by device name
filtered_files = [item for item in backup_info["Result"] if item["fileName"].startswith(device_name_to_filter)]

if not filtered_files:
    print(f"No backup files found for device '{device_name_to_filter}'.")
    sys.exit(3)  # Return unknown status (exit code 3)

# Find the latest file based on Last Modified Time
latest_file = max(filtered_files, key=lambda item: datetime.strptime(item['lastmodifiedtime'], "%d %b %Y %I:%M:%S %p %Z"))

# Convert the Last Modified Time to a datetime object
last_modified_datetime = datetime.strptime(latest_file['lastmodifiedtime'], "%d %b %Y %I:%M:%S %p %Z")

# Calculate the time difference between the Last Modified Time and the current time
time_difference = datetime.now() - last_modified_datetime

# Check if the Last Modified Time is within 24 hours
if time_difference <= timedelta(hours=24):
    print(f"OK - Latest File Name: {latest_file['fileName']} (Last Modified Time: {latest_file['lastmodifiedtime']})")
    sys.exit(0)  # Return OK status (exit code 0)

print(f"CRITICAL - Latest File Name: {latest_file['fileName']} (Last Modified Time: {latest_file['lastmodifiedtime']})")
sys.exit(2)  # Return critical status (exit code 2)
