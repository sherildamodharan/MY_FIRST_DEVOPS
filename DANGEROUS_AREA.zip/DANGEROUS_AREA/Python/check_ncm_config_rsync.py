#!/usr/bin/env python

"""
This module checks the status of the NCM config backup rsync job that runs on a daily basis between NCM central and OOB
"""

import sys
import os

# Exit codes
OK = 0
WARNING = 1
CRITICAL = 2
UNKNOWN = 3

FILE_PATH = "/opt/ManageEngine/scripts/NCM_rsync.txt"


def read_latest_entry(file_path):
    """
    Read the latest entry from the specified file.
    """
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()
            if lines:
                latest_entry = lines[-1].strip()
                return latest_entry
        print("UNKNOWN - File is empty.")
        sys.exit(UNKNOWN)

    print(f"UNKNOWN - File not found: {file_path}")
    sys.exit(UNKNOWN)


def check_entry_status(entry):
    """
    Check the status of the latest entry.
    """
    if entry.startswith("ERROR"):
        print(f"CRITICAL - Latest entry: {entry}")
        sys.exit(CRITICAL)
    elif entry.startswith("WARNING"):
        print(f"WARNING - Latest entry: {entry}")
        sys.exit(WARNING)
    elif entry.startswith("OK"):
        print(f"OK - Latest entry: {entry}")
        sys.exit(OK)

    print(f"UNKNOWN - Unknown entry status: {entry}")
    sys.exit(UNKNOWN)


latest_entry_value = read_latest_entry(FILE_PATH)
check_entry_status(latest_entry_value)
