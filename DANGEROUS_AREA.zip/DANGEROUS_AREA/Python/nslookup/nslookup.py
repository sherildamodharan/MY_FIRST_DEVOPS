import subprocess

input_file = '/Users/sheril.damodharan/Documents/DANGEROUS_AREA/Python/nslookup/hostnames.txt'
output_file = '/Users/sheril.damodharan/Documents/DANGEROUS_AREA/Python/nslookup/results.txt'

with open(input_file, 'r') as file:
    hostnames = file.read().splitlines()

with open(output_file, 'w') as file:
    for hostname in hostnames:
        try:
            output = subprocess.check_output(['host', hostname]).decode('utf-8')
            lines = output.strip().split('\n')

            if len(lines) > 1:
                file.write(f"Multiple FQDNs found for {hostname}:\n")
                file.write(output + '\n')
            else:
                file.write(output)
        except subprocess.CalledProcessError as e:
            file.write(f"Error retrieving information for {hostname}: {e}\n")







