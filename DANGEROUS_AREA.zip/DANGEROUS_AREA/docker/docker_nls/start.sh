#!/bin/bash
./fullinstall --non-interactive