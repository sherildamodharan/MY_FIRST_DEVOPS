import paramiko

def get_hostname(ip_address, username, password):
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh_client.connect(ip_address, username=username, password=password)

    # Send command to retrieve the hostname
    stdin, stdout, stderr = ssh_client.exec_command("show run | include hostname")
    output = stdout.readlines()

    # Extract the hostname from the output
    hostname = output[0].split(" ")[1].strip()

    ssh_client.close()

    return hostname

if __name__ == "__main__":
    ip_file = "ip_addresses.txt"  # Replace with the path to your IP address file
    username = "nms-ncm"
    password = "Passwrd0"

    with open(ip_file, "r") as file:
        ip_addresses = file.read().splitlines()

    for ip_address in ip_addresses:
        hostname = get_hostname(ip_address, username, password)
        print(f"IP: {ip_address} | Hostname: {hostname}")
